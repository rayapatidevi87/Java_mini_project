
package com.example.safeher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class DashboardActivity extends Activity {

    private Button btnSOS;
    private Button btnContacts;
    private Button btnLocation;
    private Button btnSafePlaces;
    private Button btnHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Connect XML buttons
        btnSOS = findViewById(R.id.btnSOS);
        btnContacts = findViewById(R.id.btnContacts);
        btnLocation = findViewById(R.id.btnLocation);
        btnSafePlaces = findViewById(R.id.btnSafePlaces);
        btnHistory = findViewById(R.id.btnHistory);

        // SOS Alert
        btnSOS.setOnClickListener(v -> {
            openScreen(SosActivity.class);
        });

        // Trusted Contacts
        btnContacts.setOnClickListener(v -> {
            openScreen(ContactsActivity.class);
        });

        // Share Location
        btnLocation.setOnClickListener(v -> {
            openScreen(ShareLocationActivity.class);
        });

        // Nearby Safe Places
        btnSafePlaces.setOnClickListener(v -> {
            openScreen(SafePlacesActivity.class);
        });

        // SOS History
        btnHistory.setOnClickListener(v -> {
            openScreen(SosHistoryActivity.class);
        });
    }

    // Common navigation method
    private void openScreen(Class<?> activityClass) {
        try {
            Intent intent = new Intent(this, activityClass);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Unable to open this module.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Back button confirmation
    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Exit SafeHer?")
                .setMessage("Do you want to exit the application?")
                .setPositiveButton("Yes", (dialog, which) -> finish())
                .setNegativeButton("No", null)
                .show();
    }
}
